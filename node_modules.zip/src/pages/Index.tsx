import { QRGeneratorApp } from "@/components/QRGeneratorApp";

const Index = () => {
  return <QRGeneratorApp />;
};

export default Index;
